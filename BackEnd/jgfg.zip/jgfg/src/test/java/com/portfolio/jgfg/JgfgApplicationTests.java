package com.portfolio.jgfg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JgfgApplicationTests {

	@Test
	void contextLoads() {
	}

}
