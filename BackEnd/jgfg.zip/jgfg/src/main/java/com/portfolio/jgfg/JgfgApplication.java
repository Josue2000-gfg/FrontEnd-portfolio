package com.portfolio.jgfg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JgfgApplication {

	public static void main(String[] args) {
		SpringApplication.run(JgfgApplication.class, args);
	}

}
